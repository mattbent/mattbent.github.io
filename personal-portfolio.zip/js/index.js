$("#home-btn").click(function() {
    $('html, body').animate({
        scrollTop: $("#home").offset().top
    }, 2000);
});
$("#about-btn").click(function() {
    $('html, body').animate({
        scrollTop: $("#about-me").offset().top
    }, 2000);
});
$("#resume-btn").click(function() {
    $('html, body').animate({
        scrollTop: $("#resume").offset().top
    }, 2000);
});
$("#projects-btn").click(function() {
    $('html, body').animate({
        scrollTop: $("#projects").offset().top
    }, 2000);
});
$("#links-btn").click(function() {
    $('html, body').animate({
        scrollTop: $("#links").offset().top
    }, 2000);
});